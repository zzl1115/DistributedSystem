package neu.edu.cs6650.proj_2_server;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Proj2ServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
