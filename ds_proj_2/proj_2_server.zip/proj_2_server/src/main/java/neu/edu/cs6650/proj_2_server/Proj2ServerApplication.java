package neu.edu.cs6650.proj_2_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proj2ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proj2ServerApplication.class, args);
	}
}
